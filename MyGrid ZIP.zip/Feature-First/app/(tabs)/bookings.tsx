import React, { useState, useCallback } from 'react';
import {
  View, Text, FlatList, Pressable, StyleSheet, ActivityIndicator, Platform,
} from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { useQuery, useMutation } from '@tanstack/react-query';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getQueryFn, apiRequest, queryClient } from '@/lib/query-client';
import { useAuth } from '@/lib/auth-context';
import Colors from '@/constants/colors';
import { fonts, spacing, radius, webTopInset } from '@/constants/theme';

type BookingFilter = 'all' | 'requested' | 'accepted' | 'in_progress' | 'footage_delivered' | 'completed' | 'declined' | 'cancelled';

export default function BookingsScreen() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [filter, setFilter] = useState<BookingFilter>('all');

  const { data: bookings = [], isLoading, refetch } = useQuery<any[]>({
    queryKey: ['/api/bookings'],
    queryFn: getQueryFn({ on401: 'returnNull' }),
    refetchOnWindowFocus: true,
    staleTime: 30 * 1000,
  });

  useFocusEffect(
    useCallback(() => {
      queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
    }, [])
  );

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      await apiRequest('PUT', `/api/bookings/${id}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
    },
  });

  const filteredBookings = filter === 'all'
    ? bookings
    : bookings.filter((b: any) => b.status === filter);

  const filters: { key: BookingFilter; label: string }[] = [
    { key: 'all', label: 'All' },
    { key: 'requested', label: 'Pending' },
    { key: 'accepted', label: 'Accepted' },
    { key: 'in_progress', label: 'Active' },
    { key: 'footage_delivered', label: 'Delivered' },
    { key: 'completed', label: 'Done' },
    { key: 'declined', label: 'Declined' },
  ];

  const topPadding = Platform.OS === 'web' ? webTopInset : insets.top;

  return (
    <View style={styles.container}>
      <View style={[styles.header, { paddingTop: topPadding + spacing.lg }]}>
        <Text style={styles.headerTitle}>Bookings</Text>
      </View>

      <View style={styles.filterRow}>
        {filters.map(f => (
          <Pressable
            key={f.key}
            onPress={() => setFilter(f.key)}
            style={[styles.filterChip, filter === f.key && styles.filterChipActive]}
          >
            <Text style={[styles.filterChipText, filter === f.key && styles.filterChipTextActive]}>
              {f.label}
            </Text>
          </Pressable>
        ))}
      </View>

      {isLoading ? (
        <ActivityIndicator color={Colors.dark.primary} style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={filteredBookings}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Ionicons name="calendar-outline" size={48} color={Colors.dark.textMuted} />
              <Text style={styles.emptyTitle}>No bookings</Text>
              <Text style={styles.emptySubtitle}>
                {user?.primaryRole === 'creator'
                  ? 'Booking requests from drivers will appear here'
                  : 'Book a media creator at an event to get started'}
              </Text>
            </View>
          }
          renderItem={({ item }) => (
            <Pressable
              onPress={() => router.push(`/booking/${item.id}` as any)}
              style={({ pressed }) => pressed ? { opacity: 0.85 } : undefined}
            >
              <BookingCard
                booking={item}
                userId={user?.id || ''}
                onAccept={() => updateStatusMutation.mutate({ id: item.id, status: 'accepted' })}
                onDecline={() => updateStatusMutation.mutate({ id: item.id, status: 'declined' })}
                onComplete={() => updateStatusMutation.mutate({ id: item.id, status: 'completed' })}
                onMessage={(otherUserId: string) => router.push(`/chat/${otherUserId}`)}
              />
            </Pressable>
          )}
        />
      )}
    </View>
  );
}

function BookingCard({ booking, userId, onAccept, onDecline, onComplete, onMessage }: {
  booking: any;
  userId: string;
  onAccept: () => void;
  onDecline: () => void;
  onComplete: () => void;
  onMessage: (userId: string) => void;
}) {
  const isCreator = userId === booking.creatorId;
  const otherUser = isCreator ? booking.driver : booking.creator;
  const otherUserId = isCreator ? booking.driverId : booking.creatorId;

  const STATUS_LABEL: Record<string, string> = {
    requested: 'Pending',
    accepted: 'Accepted',
    payment_pending: 'Payment Pending',
    paid: 'Paid',
    in_progress: 'In Progress',
    footage_delivered: 'Delivered',
    completed: 'Completed',
    declined: 'Declined',
    cancelled: 'Cancelled',
    disputed: 'Disputed',
  };

  const statusColors: Record<string, { bg: string; text: string }> = {
    requested:          { bg: Colors.dark.warningMuted, text: Colors.dark.warning },
    accepted:           { bg: Colors.dark.successMuted, text: Colors.dark.success },
    payment_pending:    { bg: Colors.dark.warningMuted, text: Colors.dark.warning },
    paid:               { bg: Colors.dark.successMuted, text: Colors.dark.success },
    in_progress:        { bg: Colors.dark.accentMuted, text: Colors.dark.accent },
    footage_delivered:  { bg: Colors.dark.accentMuted, text: Colors.dark.accent },
    completed:          { bg: Colors.dark.successMuted, text: Colors.dark.success },
    declined:           { bg: Colors.dark.errorMuted, text: Colors.dark.error },
    cancelled:          { bg: Colors.dark.errorMuted, text: Colors.dark.error },
    disputed:           { bg: Colors.dark.errorMuted, text: Colors.dark.error },
  };

  const sc = statusColors[booking.status] || statusColors.requested;

  return (
    <View style={styles.bookingCard}>
      <View style={styles.bookingCardHeader}>
        <View style={styles.bookingAvatarContainer}>
          <View style={styles.bookingAvatar}>
            <Text style={styles.bookingAvatarText}>
              {(otherUser?.displayName || '?')[0].toUpperCase()}
            </Text>
          </View>
          <View style={styles.bookingHeaderInfo}>
            <Text style={styles.bookingName} numberOfLines={1}>
              {otherUser?.displayName || 'Unknown'}
            </Text>
            <Text style={styles.bookingRole}>
              {isCreator ? 'Driver' : 'Creator'}
            </Text>
          </View>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: sc.bg }]}>
          <Text style={[styles.statusText, { color: sc.text }]}>
            {STATUS_LABEL[booking.status] || booking.status}
          </Text>
        </View>
      </View>

      <View style={styles.bookingDetails}>
        <View style={styles.bookingDetailRow}>
          <Ionicons name="flag-outline" size={16} color={Colors.dark.textMuted} />
          <Text style={styles.bookingDetailText} numberOfLines={1}>
            {booking.event?.name || 'Event'}
          </Text>
        </View>
        {booking.pkg && (
          <View style={styles.bookingDetailRow}>
            <Ionicons name="pricetag-outline" size={16} color={Colors.dark.textMuted} />
            <Text style={styles.bookingDetailText}>
              {booking.pkg.title} - ${booking.pkg.price}
            </Text>
          </View>
        )}
        {booking.notes ? (
          <View style={styles.bookingDetailRow}>
            <Ionicons name="document-text-outline" size={16} color={Colors.dark.textMuted} />
            <Text style={styles.bookingDetailText} numberOfLines={2}>
              {booking.notes}
            </Text>
          </View>
        ) : null}
      </View>

      <View style={styles.bookingActions}>
        {isCreator && booking.status === 'requested' && (
          <>
            <Pressable
              onPress={onAccept}
              style={({ pressed }) => [styles.actionButton, styles.acceptButton, pressed && { opacity: 0.8 }]}
            >
              <Ionicons name="checkmark" size={18} color={Colors.dark.success} />
            </Pressable>
            <Pressable
              onPress={onDecline}
              style={({ pressed }) => [styles.actionButton, styles.declineButton, pressed && { opacity: 0.8 }]}
            >
              <Ionicons name="close" size={18} color={Colors.dark.error} />
            </Pressable>
          </>
        )}
        {isCreator && booking.status === 'accepted' && (
          <Pressable
            onPress={onComplete}
            style={({ pressed }) => [styles.actionButton, styles.completeButton, pressed && { opacity: 0.8 }]}
          >
            <Ionicons name="checkmark-done" size={18} color={Colors.dark.accent} />
          </Pressable>
        )}
        <Pressable
          onPress={() => onMessage(otherUserId)}
          style={({ pressed }) => [styles.actionButton, styles.messageButton, pressed && { opacity: 0.8 }]}
        >
          <Ionicons name="chatbubble-outline" size={16} color={Colors.dark.textSecondary} />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark.background,
  },
  header: {
    paddingHorizontal: spacing.xl,
    marginBottom: spacing.md,
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: fonts.headingBold,
    color: Colors.dark.text,
  },
  filterRow: {
    flexDirection: 'row',
    paddingHorizontal: spacing.xl,
    marginBottom: spacing.md,
    gap: spacing.sm,
  },
  filterChip: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.full,
    backgroundColor: Colors.dark.surface,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  filterChipActive: {
    backgroundColor: Colors.dark.primaryMuted,
    borderColor: Colors.dark.primary,
  },
  filterChipText: {
    fontSize: 13,
    fontFamily: fonts.medium,
    color: Colors.dark.textMuted,
  },
  filterChipTextActive: {
    color: Colors.dark.primary,
  },
  listContent: {
    paddingHorizontal: spacing.xl,
    paddingBottom: 100,
  },
  emptyState: {
    alignItems: 'center',
    paddingTop: 60,
    gap: spacing.sm,
  },
  emptyTitle: {
    fontSize: 17,
    fontFamily: fonts.semiBold,
    color: Colors.dark.textSecondary,
  },
  emptySubtitle: {
    fontSize: 14,
    fontFamily: fonts.regular,
    color: Colors.dark.textMuted,
    textAlign: 'center',
    paddingHorizontal: spacing.xxxl,
  },
  bookingCard: {
    backgroundColor: Colors.dark.surface,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    gap: spacing.md,
  },
  bookingCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  bookingAvatarContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    flex: 1,
  },
  bookingAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.dark.surfaceHighlight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bookingAvatarText: {
    fontSize: 16,
    fontFamily: fonts.bold,
    color: Colors.dark.textSecondary,
  },
  bookingHeaderInfo: {
    flex: 1,
  },
  bookingName: {
    fontSize: 15,
    fontFamily: fonts.semiBold,
    color: Colors.dark.text,
  },
  bookingRole: {
    fontSize: 12,
    fontFamily: fonts.regular,
    color: Colors.dark.textMuted,
    textTransform: 'capitalize',
  },
  statusBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 3,
    borderRadius: radius.sm,
  },
  statusText: {
    fontSize: 11,
    fontFamily: fonts.semiBold,
    textTransform: 'capitalize',
  },
  bookingDetails: {
    gap: spacing.sm,
  },
  bookingDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  bookingDetailText: {
    fontSize: 14,
    fontFamily: fonts.regular,
    color: Colors.dark.textSecondary,
    flex: 1,
  },
  bookingActions: {
    flexDirection: 'row',
    gap: spacing.sm,
    justifyContent: 'flex-end',
  },
  actionButton: {
    width: 40,
    height: 36,
    borderRadius: radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  acceptButton: {
    backgroundColor: Colors.dark.successMuted,
  },
  declineButton: {
    backgroundColor: Colors.dark.errorMuted,
  },
  completeButton: {
    backgroundColor: Colors.dark.accentMuted,
  },
  messageButton: {
    backgroundColor: Colors.dark.surfaceHighlight,
  },
});
