import React, { useState } from 'react';
import {
  View, Text, ScrollView, Pressable, TextInput, StyleSheet,
  ActivityIndicator, Platform, KeyboardAvoidingView,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getQueryFn, apiRequest, queryClient } from '@/lib/query-client';
import { useAuth } from '@/lib/auth-context';
import Colors from '@/constants/colors';
import { fonts, spacing, radius, webTopInset, webBottomInset } from '@/constants/theme';

type Step = 'form' | 'review';

export default function CreateBookingScreen() {
  const { creatorId, eventId, packageId } = useLocalSearchParams<{ creatorId?: string; eventId?: string; packageId?: string }>();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();

  const [step, setStep] = useState<Step>('form');
  const [selectedEventId, setSelectedEventId] = useState(eventId || '');
  const [selectedPackageId, setSelectedPackageId] = useState(packageId || '');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const { data: creator } = useQuery<any>({
    queryKey: ['/api/users', creatorId],
    queryFn: getQueryFn({ on401: 'returnNull' }),
    enabled: !!creatorId,
  });

  const { data: packages = [] } = useQuery<any[]>({
    queryKey: ['/api/packages', creatorId],
    queryFn: getQueryFn({ on401: 'returnNull' }),
    enabled: !!creatorId,
  });

  const { data: events = [] } = useQuery<any[]>({
    queryKey: ['/api/events'],
    queryFn: getQueryFn({ on401: 'returnNull' }),
  });

  const selectedEvent = events.find((e: any) => e.id === selectedEventId);
  const selectedPkg = packages.find((p: any) => p.id === selectedPackageId);

  const feeCalc = (() => {
    if (!selectedPkg) return null;
    const gross = parseFloat(selectedPkg.price);
    if (isNaN(gross) || gross <= 0) return null;
    const fee = parseFloat((gross * 0.10).toFixed(2));
    const payout = parseFloat((gross - fee).toFixed(2));
    return { gross, fee, payout };
  })();

  const handleContinueToReview = () => {
    if (!selectedEventId) {
      setError('Please select an event');
      return;
    }
    if (!creatorId) {
      setError('No creator selected');
      return;
    }
    setError('');
    setStep('review');
  };

  const handleCreate = async () => {
    setLoading(true);
    setError('');
    try {
      await apiRequest('POST', '/api/bookings', {
        creatorId,
        eventId: selectedEventId,
        packageId: selectedPackageId || undefined,
        notes: notes.trim() || undefined,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
      router.back();
    } catch (err: any) {
      setError(err.message || 'Failed to create booking');
      setStep('form');
    } finally {
      setLoading(false);
    }
  };

  const topPadding = Platform.OS === 'web' ? webTopInset : insets.top;
  const bottomPadding = Math.max(insets.bottom, webBottomInset) + spacing.md;

  if (step === 'review') {
    return (
      <View style={styles.container}>
        <View style={[styles.header, { paddingTop: topPadding + spacing.sm }]}>
          <Pressable onPress={() => setStep('form')} style={styles.closeBtn}>
            <Ionicons name="chevron-back" size={24} color={Colors.dark.textSecondary} />
          </Pressable>
          <Text style={styles.headerText}>Review Request</Text>
          <View style={{ width: 40 }} />
        </View>

        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          {/* Booking summary card */}
          <View style={styles.reviewCard}>
            <Text style={styles.reviewCardTitle}>Booking Summary</Text>

            <View style={styles.reviewRow}>
              <Ionicons name="person-outline" size={15} color={Colors.dark.textMuted} />
              <View style={{ flex: 1 }}>
                <Text style={styles.reviewRowLabel}>Creator</Text>
                <Text style={styles.reviewRowValue}>{creator?.displayName || '—'}</Text>
              </View>
            </View>

            <View style={styles.reviewRow}>
              <Ionicons name="flag-outline" size={15} color={Colors.dark.textMuted} />
              <View style={{ flex: 1 }}>
                <Text style={styles.reviewRowLabel}>Event</Text>
                <Text style={styles.reviewRowValue} numberOfLines={2}>{selectedEvent?.name || '—'}</Text>
              </View>
            </View>

            {selectedEvent?.dateStart && (
              <View style={styles.reviewRow}>
                <Ionicons name="calendar-outline" size={15} color={Colors.dark.textMuted} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.reviewRowLabel}>Date</Text>
                  <Text style={styles.reviewRowValue}>
                    {new Date(selectedEvent.dateStart).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                  </Text>
                </View>
              </View>
            )}

            {selectedPkg && (
              <View style={styles.reviewRow}>
                <Ionicons name="pricetag-outline" size={15} color={Colors.dark.textMuted} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.reviewRowLabel}>Package</Text>
                  <Text style={styles.reviewRowValue}>{selectedPkg.title}</Text>
                  {selectedPkg.description ? (
                    <Text style={styles.reviewRowSub} numberOfLines={2}>{selectedPkg.description}</Text>
                  ) : null}
                </View>
              </View>
            )}

            {notes.trim() ? (
              <View style={styles.reviewRow}>
                <Ionicons name="document-text-outline" size={15} color={Colors.dark.textMuted} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.reviewRowLabel}>Notes</Text>
                  <Text style={styles.reviewRowValue}>{notes}</Text>
                </View>
              </View>
            ) : null}
          </View>

          {/* Fee breakdown */}
          {feeCalc && (
            <View style={styles.feeSummary}>
              <Text style={styles.feeSummaryTitle}>Pricing Breakdown</Text>
              <View style={styles.feeRow}>
                <Text style={styles.feeLabel}>Package price</Text>
                <Text style={styles.feeValue}>${feeCalc.gross.toFixed(2)}</Text>
              </View>
              <View style={styles.feeRow}>
                <Text style={styles.feeLabel}>MyGrid fee (10%)</Text>
                <Text style={[styles.feeValue, { color: Colors.dark.textMuted }]}>-${feeCalc.fee.toFixed(2)}</Text>
              </View>
              <View style={styles.feeDivider} />
              <View style={styles.feeRow}>
                <Text style={[styles.feeLabel, { fontFamily: fonts.semiBold, color: Colors.dark.text }]}>Total</Text>
                <Text style={[styles.feeValue, { fontFamily: fonts.bold, color: Colors.dark.primary }]}>${feeCalc.gross.toFixed(2)}</Text>
              </View>
            </View>
          )}

          {/* Confirmation message */}
          <View style={styles.confirmBox}>
            <Ionicons name="information-circle-outline" size={18} color={Colors.dark.accent} />
            <Text style={styles.confirmText}>
              You are requesting this creator for this event.
            </Text>
          </View>

          {/* Payment clarity */}
          <View style={styles.paymentClarityBox}>
            <Ionicons name="shield-checkmark-outline" size={18} color={Colors.dark.success} />
            <Text style={styles.paymentClarityText}>
              You will not be charged until the creator accepts your request.
            </Text>
          </View>

          {!!error && (
            <View style={styles.errorRow}>
              <Ionicons name="alert-circle" size={16} color={Colors.dark.error} />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          )}

          <View style={{ height: 16 }} />
        </ScrollView>

        <View style={[styles.bottomBar, { paddingBottom: bottomPadding }]}>
          <Pressable
            onPress={handleCreate}
            disabled={loading}
            style={[styles.submitButton, loading && { opacity: 0.7 }]}
          >
            <LinearGradient
              colors={[Colors.dark.primary, Colors.dark.primaryDark]}
              style={styles.submitGradient}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.submitText}>Request Booking</Text>
              )}
            </LinearGradient>
          </Pressable>
          <Pressable onPress={() => setStep('form')} style={styles.backTextBtn}>
            <Text style={styles.backTextBtnLabel}>Back</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  // Step: form
  return (
    <View style={styles.container}>
      <View style={[styles.header, { paddingTop: topPadding + spacing.sm }]}>
        <Pressable onPress={() => router.back()} style={styles.closeBtn}>
          <Ionicons name="close" size={24} color={Colors.dark.textSecondary} />
        </Pressable>
        <Text style={styles.headerText}>Book Creator</Text>
        <View style={{ width: 40 }} />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {creator && (
            <View style={styles.creatorCard}>
              <View style={styles.creatorAvatar}>
                <Text style={styles.creatorAvatarText}>
                  {(creator.displayName || '?')[0].toUpperCase()}
                </Text>
              </View>
              <View>
                <Text style={styles.creatorName}>{creator.displayName}</Text>
                <Text style={styles.creatorRole}>Media Creator</Text>
              </View>
            </View>
          )}

          <View style={styles.field}>
            <Text style={styles.label}>Select Event</Text>
            {events.map((evt: any) => (
              <Pressable
                key={evt.id}
                onPress={() => setSelectedEventId(evt.id)}
                style={[
                  styles.optionCard,
                  selectedEventId === evt.id && styles.optionSelected,
                ]}
              >
                <View style={styles.optionInfo}>
                  <Text style={styles.optionTitle}>{evt.name}</Text>
                  <Text style={styles.optionSub}>{evt.location}</Text>
                </View>
                {selectedEventId === evt.id && (
                  <Ionicons name="checkmark-circle" size={22} color={Colors.dark.primary} />
                )}
              </Pressable>
            ))}
          </View>

          {packages.length > 0 && (
            <View style={styles.field}>
              <Text style={styles.label}>Select Package (optional)</Text>
              {packages.map((pkg: any) => (
                <Pressable
                  key={pkg.id}
                  onPress={() => setSelectedPackageId(
                    selectedPackageId === pkg.id ? '' : pkg.id
                  )}
                  style={[
                    styles.optionCard,
                    selectedPackageId === pkg.id && styles.optionSelected,
                  ]}
                >
                  <View style={styles.optionInfo}>
                    <Text style={styles.optionTitle}>{pkg.title}</Text>
                    {pkg.description ? (
                      <Text style={styles.optionSub} numberOfLines={1}>{pkg.description}</Text>
                    ) : null}
                  </View>
                  <Text style={styles.optionPrice}>${pkg.price}</Text>
                </Pressable>
              ))}
            </View>
          )}

          {feeCalc && (
            <View style={styles.feeSummary}>
              <Text style={styles.feeSummaryTitle}>Booking Summary</Text>
              <View style={styles.feeRow}>
                <Text style={styles.feeLabel}>Package price</Text>
                <Text style={styles.feeValue}>${feeCalc.gross.toFixed(2)}</Text>
              </View>
              <View style={styles.feeRow}>
                <Text style={styles.feeLabel}>MyGrid fee (10%)</Text>
                <Text style={[styles.feeValue, { color: Colors.dark.textMuted }]}>-${feeCalc.fee.toFixed(2)}</Text>
              </View>
              <View style={styles.feeDivider} />
              <View style={styles.feeRow}>
                <Text style={[styles.feeLabel, { fontFamily: fonts.semiBold, color: Colors.dark.text }]}>Creator receives</Text>
                <Text style={[styles.feeValue, { fontFamily: fonts.bold, color: Colors.dark.success }]}>${feeCalc.payout.toFixed(2)}</Text>
              </View>
            </View>
          )}

          <View style={styles.field}>
            <Text style={styles.label}>Notes (optional)</Text>
            <TextInput
              style={styles.notesInput}
              placeholder="Any specific requirements or notes..."
              placeholderTextColor={Colors.dark.textMuted}
              value={notes}
              onChangeText={setNotes}
              multiline
              textAlignVertical="top"
            />
          </View>

          {!!error && (
            <View style={styles.errorRow}>
              <Ionicons name="alert-circle" size={16} color={Colors.dark.error} />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          )}

          <View style={{ height: 20 }} />
        </ScrollView>

        <View style={[styles.bottomBar, { paddingBottom: bottomPadding }]}>
          <Pressable
            onPress={handleContinueToReview}
            style={styles.submitButton}
          >
            <LinearGradient
              colors={[Colors.dark.primary, Colors.dark.primaryDark]}
              style={styles.submitGradient}
            >
              <Text style={styles.submitText}>Review Booking</Text>
              <Ionicons name="arrow-forward" size={18} color="#fff" style={{ marginLeft: 6 }} />
            </LinearGradient>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.dark.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.md, paddingBottom: spacing.sm,
  },
  closeBtn: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  headerText: { fontSize: 18, fontFamily: fonts.headingBold, color: Colors.dark.text },
  scrollContent: { paddingHorizontal: spacing.xl, paddingTop: spacing.lg },
  creatorCard: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.md,
    backgroundColor: Colors.dark.surface, borderRadius: radius.md,
    padding: spacing.lg, marginBottom: spacing.xxl,
    borderWidth: 1, borderColor: Colors.dark.border,
  },
  creatorAvatar: {
    width: 48, height: 48, borderRadius: 24,
    backgroundColor: Colors.dark.primaryMuted, alignItems: 'center', justifyContent: 'center',
  },
  creatorAvatarText: { fontSize: 18, fontFamily: fonts.bold, color: Colors.dark.primary },
  creatorName: { fontSize: 17, fontFamily: fonts.semiBold, color: Colors.dark.text },
  creatorRole: { fontSize: 13, fontFamily: fonts.regular, color: Colors.dark.textMuted },
  field: { marginBottom: spacing.xxl },
  label: {
    fontSize: 13, fontFamily: fonts.semiBold, color: Colors.dark.textSecondary,
    marginBottom: spacing.md, textTransform: 'uppercase', letterSpacing: 0.5,
  },
  optionCard: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: Colors.dark.surface, borderRadius: radius.md,
    padding: spacing.lg, marginBottom: spacing.sm,
    borderWidth: 1.5, borderColor: Colors.dark.border,
  },
  optionSelected: { borderColor: Colors.dark.primary, backgroundColor: Colors.dark.primaryMuted },
  optionInfo: { flex: 1, gap: 2 },
  optionTitle: { fontSize: 15, fontFamily: fonts.semiBold, color: Colors.dark.text },
  optionSub: { fontSize: 13, fontFamily: fonts.regular, color: Colors.dark.textMuted },
  optionPrice: { fontSize: 16, fontFamily: fonts.bold, color: Colors.dark.primary },
  notesInput: {
    backgroundColor: Colors.dark.surface, borderRadius: radius.md,
    borderWidth: 1, borderColor: Colors.dark.border,
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    minHeight: 100, fontSize: 15, fontFamily: fonts.regular, color: Colors.dark.text,
  },
  errorRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.md },
  errorText: { fontSize: 13, fontFamily: fonts.regular, color: Colors.dark.error },
  bottomBar: { paddingHorizontal: spacing.xl, paddingTop: spacing.md },
  submitButton: { borderRadius: radius.md, overflow: 'hidden' },
  submitGradient: {
    height: 52, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    borderRadius: radius.md,
  },
  submitText: { fontSize: 16, fontFamily: fonts.semiBold, color: '#fff' },
  backTextBtn: { alignItems: 'center', paddingVertical: spacing.md },
  backTextBtnLabel: { fontSize: 15, fontFamily: fonts.regular, color: Colors.dark.textSecondary },
  feeSummary: {
    backgroundColor: Colors.dark.surface,
    borderRadius: radius.md,
    padding: spacing.lg,
    marginBottom: spacing.xxl,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    gap: spacing.sm,
  },
  feeSummaryTitle: {
    fontSize: 12,
    fontFamily: fonts.semiBold,
    color: Colors.dark.textMuted,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: spacing.xs,
  },
  feeRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  feeLabel: { fontSize: 14, fontFamily: fonts.regular, color: Colors.dark.textSecondary },
  feeValue: { fontSize: 14, fontFamily: fonts.semiBold, color: Colors.dark.text },
  feeDivider: { height: 1, backgroundColor: Colors.dark.border, marginVertical: spacing.xs },

  // Review step styles
  reviewCard: {
    backgroundColor: Colors.dark.surface,
    borderRadius: radius.md,
    padding: spacing.lg,
    marginBottom: spacing.lg,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    gap: spacing.md,
  },
  reviewCardTitle: {
    fontSize: 12,
    fontFamily: fonts.semiBold,
    color: Colors.dark.textMuted,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: spacing.xs,
  },
  reviewRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.md,
  },
  reviewRowLabel: { fontSize: 11, fontFamily: fonts.regular, color: Colors.dark.textMuted, marginBottom: 2 },
  reviewRowValue: { fontSize: 15, fontFamily: fonts.semiBold, color: Colors.dark.text },
  reviewRowSub: { fontSize: 13, fontFamily: fonts.regular, color: Colors.dark.textSecondary, marginTop: 2 },
  confirmBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
    backgroundColor: Colors.dark.accentMuted,
    borderRadius: radius.md,
    padding: spacing.lg,
    marginBottom: spacing.sm,
  },
  confirmText: {
    flex: 1,
    fontSize: 14,
    fontFamily: fonts.semiBold,
    color: Colors.dark.accent,
    lineHeight: 20,
  },
  paymentClarityBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
    backgroundColor: Colors.dark.successMuted,
    borderRadius: radius.md,
    padding: spacing.lg,
    marginBottom: spacing.xxl,
  },
  paymentClarityText: {
    flex: 1,
    fontSize: 14,
    fontFamily: fonts.regular,
    color: Colors.dark.success,
    lineHeight: 20,
  },
});
