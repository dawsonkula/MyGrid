# Objective
Sprint 3: Booking conversion, transaction scaffold, content delivery, event→creator connection

# Tasks

### T001: Schema — expand enums + add packages fields + transactions + deliveries tables
- Blocked By: []
- Files: shared/schema.ts → run db:push

### T002: Backend — booking creation price snapshot + fee calc, creators-on-event endpoint, booking detail auth, delivery CRUD, transaction creation
- Blocked By: [T001]
- Files: server/routes.ts, server/storage.ts

### T003: Event detail — "Media Creators Attending" cards with Book CTA
- Blocked By: [T001]
- Files: app/event/[id].tsx

### T004: New booking detail page (app/booking/[id].tsx) — payment summary, delivery section, status actions
- Blocked By: [T002]
- Files: app/booking/[id].tsx (new)

### T005: Bookings tab — tap card → booking detail; update status filter chips
- Blocked By: [T004]
- Files: app/(tabs)/bookings.tsx

### T006: Package cards — isPopular badge + deliveryTime display; booking creation fee breakdown
- Blocked By: [T001]
- Files: app/profile/[id].tsx, app/booking/create.tsx

### T007: QA checklist + replit.md update
- Blocked By: [T004, T005, T006]
