import { Platform } from 'react-native';

export const fonts = {
  regular: 'Inter_400Regular',
  medium: 'Inter_500Medium',
  semiBold: 'Inter_600SemiBold',
  bold: 'Inter_700Bold',
  heading: 'Rajdhani_600SemiBold',
  headingBold: 'Rajdhani_700Bold',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
};

export const radius = {
  sm: 6,
  md: 10,
  lg: 14,
  xl: 20,
  full: 999,
};

export const webTopInset = Platform.OS === 'web' ? 67 : 0;
export const webBottomInset = Platform.OS === 'web' ? 34 : 0;
